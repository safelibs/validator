
var minusImg = new Image();
minusImg.src = "img/minus.gif";
var plusImg = new Image();
plusImg.src = "img/plus.gif";

var divArray = new Array();

function queue(div){ divArray[divArray.length]=div; }

function collapseTree(){
	if(document.getElementById == null) return;
	for(var i=0; i<divArray.length; i++){
		expandContract(divArray[i]);
	}
}

function expandContract(id){
	if(document.getElementById == null) return;
	var img = document.getElementById(id+'Img');
	if(img.src == minusImg.src) img.src = plusImg.src;
	else img.src = minusImg.src;

	var obj = document.getElementById(id+'Div').style;
	if(obj.display == '') obj.display = "none";
	else obj.display = '';
}